import 'package:dam_u4_proyecto2_18401194/firebase_service.dart';
import 'package:flutter/material.dart';

class Revisor extends StatefulWidget {
  const Revisor({Key? key}) : super(key: key);

  @override
  State<Revisor> createState() => _RevisorState();
}

class _RevisorState extends State<Revisor> {
  TextEditingController revisorController = TextEditingController(text: "");
  @override
  Widget build(BuildContext context) {
    final Map arguments = ModalRoute.of(context)!.settings.arguments as Map;
    revisorController=arguments['revisorver'];
    return Scaffold(
      appBar: AppBar(title: const Text("Asistencia por Revisor"),backgroundColor: Colors.blueGrey,),
      body: FutureBuilder(
        future: getAsisRevisor(revisorController.text),
        builder: ((context,snapshot){
          if(snapshot.hasData){
            return ListView.builder(itemCount: snapshot.data?.length,itemBuilder: (context,index){
              return InkWell(
                child: ListTile(
                  title: Text(snapshot.data?[index]['docente']),
                  subtitle: Text(snapshot.data?[index]['fecha']),
                  trailing: Text(snapshot.data?[index]['hora']),
                ),
              );
            }
            );
          }else{ return const Center(child: Text("no se encuentra el revisor"),);}
        }
        ),
      ),
    );
  }
}
