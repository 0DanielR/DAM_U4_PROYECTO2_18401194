import 'package:cloud_firestore/cloud_firestore.dart';

FirebaseFirestore db=FirebaseFirestore.instance;

Future<List> getAsignacion() async{
  List asignacion=[];
  CollectionReference collectionReferenceAsignacion= db.collection('asignacion');
  QuerySnapshot queryAsignacion = await collectionReferenceAsignacion.get();
  queryAsignacion.docs.forEach((documento) {
    final Map<String,dynamic> data= documento.data() as Map<String, dynamic>;
    final asig ={
      "uid":documento.id,
      "docente":data['docente'],
      "edificio":data['edificio'],
      "horario":data['horario'],
      "materia":data['materia'],
      "salon":data['salon']
    };
    asignacion.add(asig);
  });
  return asignacion;
}

Future<List> getAsisRevisor(String revisorx) async{
  List asisRevisor=[];
  QuerySnapshot queryRevisor= await db.collection('asistencia').where('revisor',isEqualTo: revisorx).get();
  queryRevisor.docs.forEach((document) {
    final Map<String,dynamic> data=document.data() as Map<String,dynamic>;
    final revisor ={
      "uid":document.id,
      "docente":data['docente'],
      "fecha":data['fecha'],
      "revisor":data['revisor'],
      "hora":data['hora']
    };
    asisRevisor.add(revisor);
  });
  return asisRevisor;
}

Future<List> getAsisDocente(String docentex) async{
  List asisRevisor=[];
  QuerySnapshot queryRevisor= await db.collection('asistencia').where('docente',isEqualTo: docentex).get();
  queryRevisor.docs.forEach((document) {
    final Map<String,dynamic> data=document.data() as Map<String,dynamic>;
    final revisor ={
      "uid":document.id,
      "docente":data['docente'],
      "fecha":data['fecha'],
      "revisor":data['revisor'],
      "hora":data['hora']
    };
    asisRevisor.add(revisor);
  });
  return asisRevisor;
}

Future<List> getAsistencia() async{
  List asistencia=[];
  CollectionReference collectionReferenceAsignacion= db.collection('asistencia');
  QuerySnapshot queryAsignacion = await collectionReferenceAsignacion.get();
  queryAsignacion.docs.forEach((documento) {
    final Map<String,dynamic> data= documento.data() as Map<String, dynamic>;
    final asis ={
      "uid":documento.id,
      "docente":data['docente'],
      "fecha":data['fecha'],
      "revisor":data['revisor'],
      "hora":data['hora']
    };
    asistencia.add(asis);
  });
  return asistencia;
}

Future<void> addAsistencia(String docente, String fecha, String revisor,String hora) async{
  await db.collection("asistencia").add({
    "docente":docente,
    "fecha":fecha,
    "revisor":revisor,
    "hora":hora
  });
}

Future<void> addAsignacion(String docente, String edificio, String horario, String materia, String salon)async{
  await db.collection("asignacion").add({
    "docente":docente,
    "edificio":edificio,
    "horario":horario,
    "materia":materia,
    "salon":salon
  });
}

Future<void> updateAsignacion(String uid,String newdocente, String newedificio, String newhorario, String newmateria, String newsalon)async{
  await db.collection("asignacion").doc(uid).set({
    "docente":newdocente,
    "edificio":newedificio,
    "horario":newhorario,
    "materia":newmateria,
    "salon":newsalon
  });
}

Future<void> deleteAsignacion(String uid)async{
  await db.collection("asignacion").doc(uid).delete();
}