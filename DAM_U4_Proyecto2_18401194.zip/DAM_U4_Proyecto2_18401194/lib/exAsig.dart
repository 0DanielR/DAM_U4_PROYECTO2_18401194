import 'package:flutter/material.dart';
import 'package:dam_u4_proyecto2_18401194/firebase_service.dart';
class ExAsig extends StatefulWidget {
  const ExAsig({Key? key}) : super(key: key);

  @override
  State<ExAsig> createState() => _ExAsigState();
}

class _ExAsigState extends State<ExAsig> {
  TextEditingController docenteController = TextEditingController(text: "");
  TextEditingController edificioController = TextEditingController(text: "");
  TextEditingController horarioController = TextEditingController(text: "");
  TextEditingController materiaController = TextEditingController(text: "");
  TextEditingController salonController = TextEditingController(text: "");
  @override
  Widget build(BuildContext context) {
    final Map arguments = ModalRoute.of(context)!.settings.arguments as Map;
    docenteController.text = arguments['docente'];
    edificioController.text= arguments['edificio'];
    horarioController.text= arguments['horario'];
    materiaController.text= arguments['materia'];
    salonController.text= arguments['salon'];
    return Scaffold(
      appBar: AppBar(title: const Text("Editar Asignacion"),),
      body: Padding(padding: const EdgeInsets.all(10.0),
        child: Column(
          children: [
            TextField(controller: docenteController,),
            TextField(controller: edificioController,),
            TextField(controller: horarioController,),
            TextField(controller: materiaController,),
            TextField(controller: salonController,),
            SizedBox(height: 20,),
            ElevatedButton(onPressed: ()async{
              await updateAsignacion(arguments['uid'], docenteController.text, edificioController.text, horarioController.text, materiaController.text, salonController.text).
              then((_){Navigator.pop(context);});
            }, child: const Text("Actualizar")),
            SizedBox(height: 20,),
            ElevatedButton(onPressed: (){alerta(arguments['uid'], docenteController.text);}, child: const Text("Eliminar"))
          ],
        ),
      ),
    );
  }

  void alerta(String uid, String docente){
    showDialog(context: context, builder: (builder){
      return AlertDialog(
        title: Text("ATENCION"),
        content: Text("¿Qué desea hacer con la placa ${docente}?"),
        actions: [
          TextButton(onPressed: (){
            deleteAsignacion(uid);
            Navigator.popUntil(context,ModalRoute.withName('/'));
          }, child: const Text("ELIMINAR")),
          TextButton(onPressed: () {
            Navigator.pop(context);
          }, child: const Text("CANCELAR"))
        ],
      );
    });
  }
}
