import 'package:flutter/material.dart';
import 'package:dam_u4_proyecto2_18401194/firebase_service.dart';

class Docente extends StatefulWidget {
  const Docente({Key? key}) : super(key: key);

  @override
  State<Docente> createState() => _DocenteState();
}

class _DocenteState extends State<Docente> {
  TextEditingController docenteController= TextEditingController(text: "");
  @override
  Widget build(BuildContext context) {
    final Map arguments = ModalRoute.of(context)!.settings.arguments as Map;
    docenteController=arguments['docentever'];
    return Scaffold(
      appBar: AppBar(title: const Text("Asistencia por Docente:"),backgroundColor: Colors.blueGrey,),
      body: FutureBuilder(
        future: getAsisDocente(docenteController.text),
        builder: ((context,snapshot){
          if(snapshot.hasData){
            return ListView.builder(itemCount: snapshot.data?.length,itemBuilder: (context,index){
              return InkWell(
                child: ListTile(
                  title: Text(snapshot.data?[index]['revisor']),
                  subtitle: Text(snapshot.data?[index]['fecha']),
                  trailing: Text(snapshot.data?[index]['hora']),
                ),
              );
            }
            );
          }else{return const Center(child: Text("no se encuentra el docente"),);}
        }
        ),
      ),
    );
  }
}
