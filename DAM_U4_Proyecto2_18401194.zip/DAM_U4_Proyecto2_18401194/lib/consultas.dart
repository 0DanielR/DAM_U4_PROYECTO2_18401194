import 'package:flutter/material.dart';

class Consultas extends StatefulWidget {
  const Consultas({Key? key}) : super(key: key);

  @override
  State<Consultas> createState() => _ConsultasState();
}

class _ConsultasState extends State<Consultas> {
  TextEditingController revisorController = TextEditingController(text: "");
  TextEditingController docenteController = TextEditingController(text: "");
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Consultas"),backgroundColor: Colors.blueGrey,),
      body: Padding(padding: const EdgeInsets.all(30),
        child: Column(
          children: [
            SizedBox(height: 10,),
            Text("Consultas por Docente"),
            TextField(controller: docenteController),
            SizedBox(height: 10,),
            ElevatedButton(onPressed: (){
              Navigator.pushNamed(context, '/docente',arguments: {
                "docentever":docenteController
              });
            }, child: const Text("VER")),
            SizedBox(height: 30,),
            Text("Consultas por Revisor"),
            TextField(controller: revisorController,),
            SizedBox(height: 10,),
            ElevatedButton(onPressed: (){
              Navigator.pushNamed(context, '/revisor',arguments: {
                "revisorver":revisorController
              });
            }, child: const Text("VER")),
          ],
        ),
      ),
    );
  }
}
