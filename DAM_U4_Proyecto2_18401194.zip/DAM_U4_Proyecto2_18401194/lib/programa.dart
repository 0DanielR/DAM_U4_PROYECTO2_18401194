import 'package:flutter/material.dart';
import 'package:dam_u4_proyecto2_18401194/asignacion.dart';
import 'package:dam_u4_proyecto2_18401194/asistencia.dart';
import 'package:dam_u4_proyecto2_18401194/consultas.dart';

class Programa extends StatefulWidget {
  const Programa({Key? key}) : super(key: key);

  @override
  State<Programa> createState() => _ProgramaState();
}

class _ProgramaState extends State<Programa> {
  int _pantalla= 1;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Asistencia"),),
      body: cargarPantallas(),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(child: Column(
              children: [
                CircleAvatar(child: Text("DAM", style: TextStyle(fontSize: 15, color: Colors.white),),
                ),
                SizedBox(height: 10,),
                Text("CONTROL DE ASISTENCIAS", style:  TextStyle(fontSize: 20, color: Colors.white),)
              ],
            ),
              decoration: BoxDecoration(color: Colors.black54),
            ),
            _items("Ver Asignación",Icons.account_balance_wallet_outlined,1),
            Divider(color: Colors.deepPurpleAccent,),
            _items("Ver Asistencia",Icons.account_balance_wallet_outlined,2),
            Divider(color: Colors.deepPurpleAccent,),
            _items("Ver Consultas",Icons.account_balance_wallet_outlined,3),
            Divider(color: Colors.deepPurpleAccent,)
          ],
        ),
      ),
    );
  }
  Widget _items(String descripcion, IconData icono, int index){
    return InkWell(
      onTap: (){
        setState(() {
          _pantalla=index;
        });
        Navigator.pop(context);
      },
      child: Padding(
        padding: EdgeInsets.all(15),
        child: Row(
          children: [
            Expanded(child: Icon(icono)),
            Expanded(child: Text(descripcion),flex: 3,)
          ],
        ),
      ),
    );
  }

  Widget cargarPantallas(){
    switch(_pantalla){
      case 1:{
        return Asignacion();
      }
      break;
      case 2:{
        return Asistencia();
      }
      break;
      case 3:{
        return Consultas();
      }
      break;
      default:
        return ListView();
    }
  }
}
