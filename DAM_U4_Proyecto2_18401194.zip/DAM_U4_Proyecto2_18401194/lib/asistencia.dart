import 'package:flutter/material.dart';
import 'package:dam_u4_proyecto2_18401194/firebase_service.dart';

class Asistencia extends StatefulWidget {
  const Asistencia({Key? key}) : super(key: key);

  @override
  State<Asistencia> createState() => _AsistenciaState();
}

class _AsistenciaState extends State<Asistencia> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Asistencia"),backgroundColor: Colors.blueGrey,),
      body: FutureBuilder(
        future: getAsistencia(),
        builder: ((context,snapshot){
          if(snapshot.hasData){
            return ListView.builder(itemCount: snapshot.data?.length ,itemBuilder: (context,index){
              return InkWell(onTap: (){},child: ListTile(
                title: Text(snapshot.data?[index]['fecha']),
                subtitle: Text(snapshot.data?[index]['docente']),
                trailing: Text(snapshot.data?[index]['revisor']),
              ),
              );
            }
            );
          }else{return const Center(child: CircularProgressIndicator(),);}
        }
        ),
      ),
      floatingActionButton: FloatingActionButton(onPressed: ()async{await Navigator.pushNamed(context, "/addAsis");setState(() {

      });},child: Icon(Icons.add),),
    );
  }
}
