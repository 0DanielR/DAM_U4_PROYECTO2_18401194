import 'package:flutter/material.dart';
import 'package:dam_u4_proyecto2_18401194/firebase_service.dart';

class InAsig extends StatefulWidget {
  const InAsig({Key? key}) : super(key: key);

  @override
  State<InAsig> createState() => _InAsigState();
}
//String docente, String edificio, String horario, String materia, String salon
class _InAsigState extends State<InAsig> {
  TextEditingController docenteController = TextEditingController(text: "");
  TextEditingController edificioController = TextEditingController(text: "");
  TextEditingController horarioController = TextEditingController(text: "");
  TextEditingController materiaController = TextEditingController(text: "");
  TextEditingController salonController = TextEditingController(text: "");
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Agregar Asignacion"),),
      body: Padding(padding: const EdgeInsets.all(10),
      child: Column(
        children: [
          TextField(
            controller: docenteController,
            decoration: const InputDecoration(hintText: 'docente'),
          ),
          TextField(
            controller: edificioController,
            decoration: const InputDecoration(hintText: 'edificio'),
          ),
          TextField(
            controller: horarioController,
            decoration: const InputDecoration(hintText: 'horario'),
          ),
          TextField(
            controller: materiaController,
            decoration: const InputDecoration(hintText: 'materia'),
          ),
          TextField(
            controller: salonController,
            decoration: const InputDecoration(hintText: 'salon'),
          ),
          ElevatedButton(onPressed: ()async{
            await addAsignacion(docenteController.text, edificioController.text, horarioController.text, materiaController.text, salonController.text).
            then((_){Navigator.pop(context);});
          }, child: const Text("Guardar"))
        ],
      ),
      ),
    );
  }
}
