import 'package:flutter/material.dart';
import 'package:dam_u4_proyecto2_18401194/firebase_service.dart';

class Asignacion extends StatefulWidget {
  const Asignacion({Key? key}) : super(key: key);

  @override
  State<Asignacion> createState() => _AsignacionState();
}

class _AsignacionState extends State<Asignacion> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Asignacion"),backgroundColor: Colors.blueGrey,),
      body: FutureBuilder(
        future: getAsignacion(),
        builder: ((context,snapshot){
          if(snapshot.hasData){
            return ListView.builder(itemCount: snapshot.data?.length, itemBuilder: (context,index){
              return InkWell( onTap: ()async{
                await Navigator.pushNamed(context, '/exAsig',
                arguments: {
                  "docente":snapshot.data?[index]['docente'],
                  "edificio":snapshot.data?[index]['edificio'],
                  "horario":snapshot.data?[index]['horario'],
                  "materia":snapshot.data?[index]['materia'],
                  "salon":snapshot.data?[index]['salon'],
                  "uid":snapshot.data?[index]['uid'],
                }
                );setState(() {

                });
              },
                child: ListTile(
                  title: Text(snapshot.data?[index]['docente']),
                  subtitle: Text(snapshot.data?[index]['horario']),
                  trailing: Text(snapshot.data?[index]['salon']),
                ),
              );
            },
            );
          }else{
            return const Center(child: CircularProgressIndicator(),);
          }
        }),
      ),
      floatingActionButton: FloatingActionButton(onPressed: ()async{
        await Navigator.pushNamed(context, '/addAsig');setState(() {

        });
      },
        child: Icon(Icons.add),
      ),
    );
  }
}
