package com.example.dam_u4_proyecto2_18401194

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
